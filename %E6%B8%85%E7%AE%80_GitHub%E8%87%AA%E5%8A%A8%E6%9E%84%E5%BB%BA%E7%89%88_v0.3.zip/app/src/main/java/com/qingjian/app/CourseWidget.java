package com.qingjian.app;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import java.util.ArrayList;
public class CourseWidget extends AppWidgetProvider {
 private static final int[] IDS={R.id.course1,R.id.course2,R.id.course3,R.id.course4,R.id.course5};
 public static void refresh(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);ComponentName n=new ComponentName(c,CourseWidget.class);for(int id:m.getAppWidgetIds(n))update(c,m,id);}
 static void update(Context c,AppWidgetManager m,int id){RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_courses);ArrayList<CourseStore.Course> courses=CourseStore.load(c);
 Intent settings=new Intent(c,MainActivity.class);PendingIntent settingsPi=PendingIntent.getActivity(c,500,settings,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);v.setOnClickPendingIntent(R.id.widget_title,settingsPi);
 for(int i=0;i<5;i++){int row=IDS[i];if(i<courses.size()){v.setTextViewText(row,"↗   "+courses.get(i).title);Intent open=new Intent(c,OpenActivity.class);open.putExtra("index",i);PendingIntent pi=PendingIntent.getActivity(c,100+i,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);v.setOnClickPendingIntent(row,pi);}else{v.setTextViewText(row,i==courses.size()?"＋  添加课程":"");v.setOnClickPendingIntent(row,settingsPi);}}
 m.updateAppWidget(id,v);
 }
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)update(c,m,id);}
}
