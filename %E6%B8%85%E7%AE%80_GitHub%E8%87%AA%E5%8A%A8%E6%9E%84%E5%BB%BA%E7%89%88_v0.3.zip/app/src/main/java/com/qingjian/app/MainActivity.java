package com.qingjian.app;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class MainActivity extends Activity {
 LinearLayout root,items;ArrayList<CourseStore.Course> courses;
 @Override public void onCreate(Bundle b){super.onCreate(b);courses=CourseStore.load(this);render();handleShare(getIntent());}
 @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);handleShare(i);}
 void handleShare(Intent i){if(Intent.ACTION_SEND.equals(i.getAction())&&"text/plain".equals(i.getType())){String s=i.getStringExtra(Intent.EXTRA_TEXT);if(s!=null){Matcher m=Pattern.compile("https?://[^\\s]+",Pattern.CASE_INSENSITIVE).matcher(s);if(m.find()){String url=m.group().replaceAll("[，。；,;]+$","");showEditor(null,url);}else Toast.makeText(this,"分享内容没有找到网址",Toast.LENGTH_SHORT).show();}}}
 TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(25,61,53));t.setPadding(12,12,12,12);return t;}
 Button button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setOnClickListener(v->r.run());return b;}
 void render(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(22,32,22,20);root.setBackgroundColor(Color.rgb(246,248,245));ScrollView scroll=new ScrollView(this);scroll.addView(root);setContentView(scroll);root.addView(text("清简 · 我的课程",25));root.addView(text("桌面课程卡片 · 点击打开课程网页，需要时再前往B站App",13));root.addView(button("＋ 添加课程",()->showEditor(null,null)));items=new LinearLayout(this);items.setOrientation(LinearLayout.VERTICAL);root.addView(items);root.addView(text("长按桌面空白处 → 小组件 → 清简，添加到桌面。最多5门课程。",13));refreshList();}
 void refreshList(){items.removeAllViews();if(courses.isEmpty())items.addView(text("还没有课程。可从B站分享链接到清简，或手动添加。",14));for(int i=0;i<courses.size();i++){final int idx=i;CourseStore.Course c=courses.get(i);LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(5,8,5,8);card.addView(text((i+1)+". "+c.title,18));card.addView(text(c.url,11));LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);actions.addView(button("打开",()->{Intent a=new Intent(this,OpenActivity.class);a.putExtra("index",idx);startActivity(a);}));actions.addView(button("编辑",()->showEditor(idx,null)));actions.addView(button("↑",()->move(idx,-1)));actions.addView(button("↓",()->move(idx,1)));actions.addView(button("删除",()->new AlertDialog.Builder(this).setMessage("删除「"+c.title+"」？").setNegativeButton("取消",null).setPositiveButton("删除",(d,w)->{courses.remove(idx);persist();}).show()));HorizontalScrollView h=new HorizontalScrollView(this);h.addView(actions);card.addView(h);items.addView(card);}}
 void move(int i,int delta){int j=i+delta;if(j<0||j>=courses.size())return;CourseStore.Course c=courses.remove(i);courses.add(j,c);persist();}
 void persist(){CourseStore.save(this,courses);refreshList();}
 void showEditor(Integer idx,String prefill){if(idx==null&&courses.size()>=5){Toast.makeText(this,"最多添加5门课程",Toast.LENGTH_SHORT).show();return;}LinearLayout form=new LinearLayout(this);form.setPadding(22,12,22,0);form.setOrientation(LinearLayout.VERTICAL);EditText name=new EditText(this);name.setHint("课程名称，如：数学物理方法");name.setSingleLine(true);EditText url=new EditText(this);url.setHint("B站分享链接（https://...）");url.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);if(idx!=null){name.setText(courses.get(idx).title);url.setText(courses.get(idx).url);}else if(prefill!=null)url.setText(prefill);form.addView(name);form.addView(url);new AlertDialog.Builder(this).setTitle(idx==null?"添加课程":"编辑课程").setView(form).setNegativeButton("取消",null).setPositiveButton("保存",(d,w)->{String n=name.getText().toString().trim(),u=url.getText().toString().trim();if(n.isEmpty()||u.isEmpty()||!(u.startsWith("https://")||u.startsWith("http://"))){Toast.makeText(this,"请输入名称和有效的网页链接",Toast.LENGTH_LONG).show();return;}if(idx==null)courses.add(new CourseStore.Course(n,u));else courses.set(idx,new CourseStore.Course(n,u));persist();}).show();}
}
