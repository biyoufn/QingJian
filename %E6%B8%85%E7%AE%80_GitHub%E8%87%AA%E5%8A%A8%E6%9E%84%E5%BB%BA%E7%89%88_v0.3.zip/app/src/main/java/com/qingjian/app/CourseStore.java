package com.qingjian.app;
import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
public final class CourseStore {
 public static class Course { public String title,url; Course(String t,String u){title=t;url=u;} }
 public static ArrayList<Course> load(Context c){ArrayList<Course> a=new ArrayList<>();try{JSONArray j=new JSONArray(c.getSharedPreferences("courses",0).getString("items","[]"));for(int i=0;i<j.length();i++){JSONObject o=j.getJSONObject(i);a.add(new Course(o.getString("title"),o.getString("url")));}}catch(Exception ignored){}return a;}
 public static void save(Context c,ArrayList<Course> a){JSONArray j=new JSONArray();try{for(Course x:a){JSONObject o=new JSONObject();o.put("title",x.title);o.put("url",x.url);j.put(o);}}catch(Exception ignored){}c.getSharedPreferences("courses",0).edit().putString("items",j.toString()).apply();CourseWidget.refresh(c);}
}
