package com.qingjian.app;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import java.util.ArrayList;
public class OpenActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b);ArrayList<CourseStore.Course> list=CourseStore.load(this);int i=getIntent().getIntExtra("index",-1);if(i<0||i>=list.size()){finish();return;}
 String url=list.get(i).url;try{Uri uri=Uri.parse(url);if(!"https".equalsIgnoreCase(uri.getScheme())&&!"http".equalsIgnoreCase(uri.getScheme()))throw new IllegalArgumentException("仅支持网页链接");
 Intent browser=new Intent(Intent.ACTION_VIEW,uri);
 browser.addCategory(Intent.CATEGORY_BROWSABLE);
 startActivity(browser);

 }catch(Exception e){Toast.makeText(this,"无法打开课程，请检查链接",Toast.LENGTH_LONG).show();}finish();}
}
